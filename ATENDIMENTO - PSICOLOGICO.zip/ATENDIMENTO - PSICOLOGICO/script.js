document.addEventListener('DOMContentLoaded', () => {

    // --- Seletores Globais ---
    const header = document.getElementById('main-header');
    const navLinksContainer = document.querySelector('header nav .nav-links');
    const navLinks = document.querySelectorAll('header nav .nav-links a[href^="#"]');
    const menuToggle = document.querySelector('.menu-toggle');
    const modal = document.getElementById('agendarModal');
    const openModalButtons = document.querySelectorAll('.openModalLink, #openModalBtn, #whatsapp-button');
    const closeModalButton = document.querySelector('.modal .close-button');
    const agendamentoForm = document.getElementById('agendamentoForm');
    const timeSlotsContainer = document.getElementById('time-slots');
    const calendarArea = document.getElementById('calendar-area');
    const selectedSlotInput = document.getElementById('selectedSlot');
    const descricaoInput = document.getElementById('descricao'); // Seletor para descrição

    // --- Ano Atual no Rodapé ---
    const yearSpan = document.getElementById('currentYear');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // --- Menu Mobile ---
    if (menuToggle && navLinksContainer) {
        menuToggle.addEventListener('click', () => {
            navLinksContainer.classList.toggle('active');
        });
        // Fecha o menu ao clicar em um link no mobile
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (navLinksContainer.classList.contains('active')) {
                    navLinksContainer.classList.remove('active');
                }
            });
        });
    }

    // --- Rolagem Suave e Highlight da Navegação ---
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                const headerOffset = header ? header.offsetHeight : 70;
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                window.scrollTo({ top: offsetPosition, behavior: "smooth" });
                navLinks.forEach(nav => nav.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
    const activateNavOnScroll = () => {
        let currentSection = '';
        const sections = document.querySelectorAll('main section[id]');
        const headerOffset = header ? header.offsetHeight : 70;
        sections.forEach(section => {
            const sectionTop = section.offsetTop - headerOffset - 50;
            if (window.pageYOffset >= sectionTop) {
                currentSection = section.getAttribute('id');
            }
        });
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
        const homeLink = document.querySelector('header nav .nav-links a[href="#home"]');
        const isActiveSectionFound = Array.from(navLinks).some(link => link.classList.contains('active'));
         if (homeLink && window.pageYOffset < (sections.length > 0 ? sections[0].offsetTop - headerOffset * 2 : 300)) {
             navLinks.forEach(link => link.classList.remove('active'));
            homeLink.classList.add('active');
         } else if (homeLink && !isActiveSectionFound && window.pageYOffset >= (sections.length > 0 ? sections[0].offsetTop - headerOffset * 2 : 300)) {
             homeLink.classList.remove('active');
         }
    };
    window.addEventListener('scroll', activateNavOnScroll);
    activateNavOnScroll();

    // --- Controle do Modal ---
    const openModal = () => {
        if (modal) {
            modal.style.display = "block";
            generateAvailableDays(); // Gera os dias ao abrir
            timeSlotsContainer.innerHTML = '<p class="info-text">Selecione um dia acima para ver os horários.</p>'; // Limpa horários
            selectedSlotInput.value = ''; // Reseta seleção
        }
    };
    const closeModal = () => {
         if (modal) {
            modal.style.display = "none";
            selectedSlotInput.value = '';
        }
    };
    openModalButtons.forEach(btn => btn.addEventListener('click', openModal));
    if (closeModalButton) { closeModalButton.addEventListener('click', closeModal); }
    window.addEventListener('click', (event) => { if (event.target == modal) { closeModal(); } });
    window.addEventListener('keydown', (event) => { if (event.key === 'Escape' && modal && modal.style.display === "block") { closeModal(); } });

    // --- Lógica de Geração de Dias e Horários ---

    const bookedSlots = JSON.parse(sessionStorage.getItem('bookedSlots')) || {};

    const generateAvailableDays = () => {
        calendarArea.innerHTML = '';
        const today = new Date();
        const availableDaysToShow = 7;
        let daysCount = 0;
        let currentDate = new Date(today);

        while (daysCount < availableDaysToShow) {
            currentDate.setDate(currentDate.getDate() + 1);
            const dayOfWeek = currentDate.getDay();

            if (dayOfWeek === 0 || dayOfWeek === 6) {
                continue;
            }

            const dayFormatted = currentDate.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' });
            const dayKey = currentDate.toISOString().split('T')[0];

            const dayButton = document.createElement('button');
            dayButton.type = 'button';
            dayButton.classList.add('day-button');
            dayButton.textContent = dayFormatted;
            dayButton.dataset.dayKey = dayKey;

            dayButton.addEventListener('click', () => {
                const currentlySelectedDay = calendarArea.querySelector('.selected');
                if (currentlySelectedDay) {
                    currentlySelectedDay.classList.remove('selected');
                }
                dayButton.classList.add('selected');
                generateTimeSlotsForDate(dayKey);
                selectedSlotInput.value = '';
            });

            calendarArea.appendChild(dayButton);
            daysCount++;
        }
         if (calendarArea.innerHTML === '') {
             calendarArea.innerHTML = '<p class="loading-text">Não há dias disponíveis na próxima semana.</p>';
         }
    };

    const generateTimeSlotsForDate = (dayKey) => {
        timeSlotsContainer.innerHTML = '';
        selectedSlotInput.value = '';

        const now = new Date();

        for (let hour = 8; hour < 18; hour++) {
            const slotTime = `${hour.toString().padStart(2, '0')}:00`;
            const slotDateTime = `${dayKey} ${slotTime}`;

            const button = document.createElement('button');
            button.type = 'button';
            button.classList.add('time-slot-button');
            button.textContent = slotTime;
            button.dataset.dateTime = slotDateTime;

            const slotFullDate = new Date(`${dayKey}T${slotTime}:00`);

            if (slotFullDate < now) {
                 button.classList.add('booked');
                 button.disabled = true;
                 button.title = "Horário indisponível (passado)";
            } else if (bookedSlots[slotDateTime]) {
                button.classList.add('booked');
                button.disabled = true;
                button.title = "Horário recém agendado";
            } else {
                button.addEventListener('click', () => {
                    const currentlySelected = timeSlotsContainer.querySelector('.selected');
                    if (currentlySelected) {
                        currentlySelected.classList.remove('selected');
                    }
                    button.classList.add('selected');
                    selectedSlotInput.value = button.dataset.dateTime;
                    console.log("Horário selecionado:", selectedSlotInput.value);
                });
            }
            timeSlotsContainer.appendChild(button);
        }
         if (timeSlotsContainer.innerHTML === '') {
             timeSlotsContainer.innerHTML = '<p class="info-text">Não há horários disponíveis para este dia.</p>';
         }
    };

    // --- Submissão do Formulário (Simulação - com Descrição) ---
    if (agendamentoForm) {
        agendamentoForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const nome = document.getElementById('nomeCompleto').value.trim();
            const telefone = document.getElementById('telefone').value.trim();
            const email = document.getElementById('email').value.trim();
            const tipoAtendimento = document.getElementById('tipoAtendimento').value;
            const descricao = descricaoInput.value.trim();
            const horarioSelecionado = selectedSlotInput.value;

            if (!nome || !telefone || !email || !tipoAtendimento || !horarioSelecionado) {
                alert('Por favor, preencha os campos obrigatórios (Nome, Telefone, E-mail, Tipo de Atendimento) e selecione um dia e horário.');
                return;
            }

            let horarioFormatado = 'N/A';
             if(horarioSelecionado) {
                 try {
                    const [data, hora] = horarioSelecionado.split(' ');
                    const dateObj = new Date(data + 'T00:00:00');
                     horarioFormatado = `${dateObj.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })} às ${hora}`;
                } catch (error) {
                    console.error("Erro ao formatar data/hora:", error);
                    horarioFormatado = horarioSelecionado;
                }
             }

            const mensagem = `--- Solicitação de Agendamento ---\n` +
                             `Nome: ${nome}\n` +
                             `Telefone: ${telefone}\n` +
                             `E-mail: ${email}\n` +
                             `Tipo de Atendimento: ${tipoAtendimento}\n` +
                             `Horário Solicitado: ${horarioFormatado}\n` +
                             `Descrição Breve: ${descricao || '(Não informada)'}`;

            console.log(mensagem);
            alert("Solicitação recebida!\n\n" + mensagem + "\n\nEntraremos em contato em breve para confirmar seu agendamento.\n(Isso é uma simulação. Nenhum dado foi enviado.)");

            const bookedButton = timeSlotsContainer.querySelector(`button[data-date-time="${horarioSelecionado}"]`);
            if (bookedButton) {
                bookedButton.classList.remove('selected');
                bookedButton.classList.add('booked');
                bookedButton.disabled = true;
                bookedSlots[horarioSelecionado] = true;
                sessionStorage.setItem('bookedSlots', JSON.stringify(bookedSlots));
            }

            agendamentoForm.reset();
            selectedSlotInput.value = '';
            timeSlotsContainer.innerHTML = '<p class="info-text">Selecione um dia acima para ver os horários.</p>';
             const selectedDayButton = calendarArea.querySelector('.selected');
             if(selectedDayButton) selectedDayButton.classList.remove('selected');

            closeModal();
        });
    }

    console.log("Scripts do site Jessica Freitas carregados e atualizados.");
});
